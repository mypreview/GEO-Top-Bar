= 1.1.0 =
* Updated language file.
* Updated GEO IP address database.
* Added support to hide top bar on product post type.
* Compatibility with WordPress 4.9.4

= 1.0.0 =
* Initial release.
